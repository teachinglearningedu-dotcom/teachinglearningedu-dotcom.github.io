# BSCS Strategy Guides

80 one-page guides. Each contains practical steps, teacher language, five top tips, common pitfalls and linked further reading. The guides form a menu for a useful next step; they are not a checklist to use all at once.

Classroom scripts are illustrative. The agreed BSCS routines take precedence over practitioner suggestions. Further-reading links sometimes support one component of the guide; attribution does not imply that a named technique is separately proven by the EEF.

## Lesson Preparation

| Code | Guide | PDF | Word |
| --- | --- | --- | --- |
| LP01 | Planning backwards from what students need to learn | [PDF](individual/BSCS_LP01_planning-backwards-from-what-students-need-to-learn.pdf) | [Word](individual/BSCS_LP01_planning-backwards-from-what-students-need-to-learn.docx) |
| LP02 | Prerequisite knowledge checks: identifying the foundations for new learning | [PDF](individual/BSCS_LP02_prerequisite-knowledge-checks-identifying-the-foundations-for-new-learning.pdf) | [Word](individual/BSCS_LP02_prerequisite-knowledge-checks-identifying-the-foundations-for-new-learning.docx) |
| LP03 | Anticipating misconceptions and planning how to uncover them | [PDF](individual/BSCS_LP03_anticipating-misconceptions-and-planning-how-to-uncover-them.pdf) | [Word](individual/BSCS_LP03_anticipating-misconceptions-and-planning-how-to-uncover-them.docx) |
| LP04 | Diagnostic questions: planning questions that reveal understanding | [PDF](individual/BSCS_LP04_diagnostic-questions-planning-questions-that-reveal-understanding.pdf) | [Word](individual/BSCS_LP04_diagnostic-questions-planning-questions-that-reveal-understanding.docx) |
| LP05 | Scaffolding: preparing support and deciding when to remove it | [PDF](individual/BSCS_LP05_scaffolding-preparing-support-and-deciding-when-to-remove-it.pdf) | [Word](individual/BSCS_LP05_scaffolding-preparing-support-and-deciding-when-to-remove-it.docx) |
| LP06 | Atomisation: breaking learning into prerequisite and new knowledge | [PDF](individual/BSCS_LP06_atomisation-breaking-learning-into-prerequisite-and-new-knowledge.pdf) | [Word](individual/BSCS_LP06_atomisation-breaking-learning-into-prerequisite-and-new-knowledge.docx) |
| LP07 | Purpose: helping students understand what they are learning and why | [PDF](individual/BSCS_LP07_purpose-helping-students-understand-what-they-are-learning-and-why.pdf) | [Word](individual/BSCS_LP07_purpose-helping-students-understand-what-they-are-learning-and-why.docx) |

## Climate & Culture

| Code | Guide | PDF | Word |
| --- | --- | --- | --- |
| CC01 | Entry routines: establishing a purposeful start | [PDF](individual/BSCS_CC01_entry-routines-establishing-a-purposeful-start.pdf) | [Word](individual/BSCS_CC01_entry-routines-establishing-a-purposeful-start.docx) |
| CC02 | Teaching and rehearsing classroom routines | [PDF](individual/BSCS_CC02_teaching-and-rehearsing-classroom-routines.pdf) | [Word](individual/BSCS_CC02_teaching-and-rehearsing-classroom-routines.docx) |
| CC03 | Signal for attention: securing readiness before teaching | [PDF](individual/BSCS_CC03_signal-for-attention-securing-readiness-before-teaching.pdf) | [Word](individual/BSCS_CC03_signal-for-attention-securing-readiness-before-teaching.docx) |
| CC04 | Checks for listening: instructions, explanations and classmates | [PDF](individual/BSCS_CC04_checks-for-listening-instructions-explanations-and-classmates.pdf) | [Word](individual/BSCS_CC04_checks-for-listening-instructions-explanations-and-classmates.docx) |
| CC05 | Behaviour scripts: correcting calmly and precisely | [PDF](individual/BSCS_CC05_behaviour-scripts-correcting-calmly-and-precisely.pdf) | [Word](individual/BSCS_CC05_behaviour-scripts-correcting-calmly-and-precisely.docx) |
| CC06 | Exit routines: ending lessons calmly and efficiently | [PDF](individual/BSCS_CC06_exit-routines-ending-lessons-calmly-and-efficiently.pdf) | [Word](individual/BSCS_CC06_exit-routines-ending-lessons-calmly-and-efficiently.docx) |
| CC07 | Clear instructions and front-loading: specify participation before the task | [PDF](individual/BSCS_CC07_clear-instructions-and-front-loading-specify-participation-before-the-task.pdf) | [Word](individual/BSCS_CC07_clear-instructions-and-front-loading-specify-participation-before-the-task.docx) |
| CC08 | Habits of attention: teaching purposeful listening routines | [PDF](individual/BSCS_CC08_habits-of-attention-teaching-purposeful-listening-routines.pdf) | [Word](individual/BSCS_CC08_habits-of-attention-teaching-purposeful-listening-routines.docx) |
| CC09 | Classroom transitions: moving smoothly between learning activities | [PDF](individual/BSCS_CC09_classroom-transitions-moving-smoothly-between-learning-activities.pdf) | [Word](individual/BSCS_CC09_classroom-transitions-moving-smoothly-between-learning-activities.docx) |
| CC10 | Precorrections: preventing predictable problems before they start | [PDF](individual/BSCS_CC10_precorrections-preventing-predictable-problems-before-they-start.pdf) | [Word](individual/BSCS_CC10_precorrections-preventing-predictable-problems-before-they-start.docx) |
| CC11 | Making participation safe: prepare, rehearse and respond warmly | [PDF](individual/BSCS_CC11_making-participation-safe-prepare-rehearse-and-respond-warmly.pdf) | [Word](individual/BSCS_CC11_making-participation-safe-prepare-rehearse-and-respond-warmly.docx) |

## Do Now

| Code | Guide | PDF | Word |
| --- | --- | --- | --- |
| DN01 | Do Now: preparing students for learning | [PDF](individual/BSCS_DN01_do-now-preparing-students-for-learning.pdf) | [Word](individual/BSCS_DN01_do-now-preparing-students-for-learning.docx) |
| DN02 | Retrieval practice: strengthening recall | [PDF](individual/BSCS_DN02_retrieval-practice-strengthening-recall.pdf) | [Word](individual/BSCS_DN02_retrieval-practice-strengthening-recall.docx) |
| DN03 | Spaced retrieval: revisiting knowledge over time | [PDF](individual/BSCS_DN03_spaced-retrieval-revisiting-knowledge-over-time.pdf) | [Word](individual/BSCS_DN03_spaced-retrieval-revisiting-knowledge-over-time.docx) |
| DN04 | Low-stakes quizzes: making retrieval accessible and challenging | [PDF](individual/BSCS_DN04_low-stakes-quizzes-making-retrieval-accessible-and-challenging.pdf) | [Word](individual/BSCS_DN04_low-stakes-quizzes-making-retrieval-accessible-and-challenging.docx) |
| DN05 | Do Now feedback: checking responses and addressing gaps | [PDF](individual/BSCS_DN05_do-now-feedback-checking-responses-and-addressing-gaps.pdf) | [Word](individual/BSCS_DN05_do-now-feedback-checking-responses-and-addressing-gaps.docx) |

## Explain

| Code | Guide | PDF | Word |
| --- | --- | --- | --- |
| EX01 | Small steps: explaining new ideas in manageable chunks | [PDF](individual/BSCS_EX01_small-steps-explaining-new-ideas-in-manageable-chunks.pdf) | [Word](individual/BSCS_EX01_small-steps-explaining-new-ideas-in-manageable-chunks.docx) |
| EX02 | The visualiser: live modelling step by step | [PDF](individual/BSCS_EX02_the-visualiser-live-modelling-step-by-step.pdf) | [Word](individual/BSCS_EX02_the-visualiser-live-modelling-step-by-step.docx) |
| EX03 | Think aloud: making expert thinking visible | [PDF](individual/BSCS_EX03_think-aloud-making-expert-thinking-visible.pdf) | [Word](individual/BSCS_EX03_think-aloud-making-expert-thinking-visible.docx) |
| EX04 | Examples and non-examples: clarifying what counts | [PDF](individual/BSCS_EX04_examples-and-non-examples-clarifying-what-counts.pdf) | [Word](individual/BSCS_EX04_examples-and-non-examples-clarifying-what-counts.docx) |
| EX05 | Dual coding: using diagrams and words together | [PDF](individual/BSCS_EX05_dual-coding-using-diagrams-and-words-together.pdf) | [Word](individual/BSCS_EX05_dual-coding-using-diagrams-and-words-together.docx) |
| EX06 | Explicit vocabulary teaching: developing keystone vocabulary | [PDF](individual/BSCS_EX06_explicit-vocabulary-teaching-developing-keystone-vocabulary.pdf) | [Word](individual/BSCS_EX06_explicit-vocabulary-teaching-developing-keystone-vocabulary.docx) |
| EX07 | I Do We Do You Do: moving towards independence | [PDF](individual/BSCS_EX07_i-do-we-do-you-do-moving-towards-independence.pdf) | [Word](individual/BSCS_EX07_i-do-we-do-you-do-moving-towards-independence.docx) |
| EX08 | Worked examples: showing a complete solution | [PDF](individual/BSCS_EX08_worked-examples-showing-a-complete-solution.pdf) | [Word](individual/BSCS_EX08_worked-examples-showing-a-complete-solution.docx) |
| EX09 | Explaining with precision: plan, sequence and rehearse the explanation | [PDF](individual/BSCS_EX09_explaining-with-precision-plan-sequence-and-rehearse-the-explanation.pdf) | [Word](individual/BSCS_EX09_explaining-with-precision-plan-sequence-and-rehearse-the-explanation.docx) |
| EX10 | Cognitive simplicity: designing slides and resources that support attention | [PDF](individual/BSCS_EX10_cognitive-simplicity-designing-slides-and-resources-that-support-attention.pdf) | [Word](individual/BSCS_EX10_cognitive-simplicity-designing-slides-and-resources-that-support-attention.docx) |
| EX11 | Live drawing: building a representation step by step | [PDF](individual/BSCS_EX11_live-drawing-building-a-representation-step-by-step.pdf) | [Word](individual/BSCS_EX11_live-drawing-building-a-representation-step-by-step.docx) |
| EX12 | Storytelling and analogies: making an explanation coherent and memorable | [PDF](individual/BSCS_EX12_storytelling-and-analogies-making-an-explanation-coherent-and-memorable.pdf) | [Word](individual/BSCS_EX12_storytelling-and-analogies-making-an-explanation-coherent-and-memorable.docx) |

## Secure Learning Through Practice

| Code | Guide | PDF | Word |
| --- | --- | --- | --- |
| PR01 | Guided practice: checking readiness for independent work | [PDF](individual/BSCS_PR01_guided-practice-checking-readiness-for-independent-work.pdf) | [Word](individual/BSCS_PR01_guided-practice-checking-readiness-for-independent-work.docx) |
| PR02 | Completion problems: bridging modelling and independence | [PDF](individual/BSCS_PR02_completion-problems-bridging-modelling-and-independence.pdf) | [Word](individual/BSCS_PR02_completion-problems-bridging-modelling-and-independence.docx) |
| PR03 | Fading scaffolds: removing support as students become secure | [PDF](individual/BSCS_PR03_fading-scaffolds-removing-support-as-students-become-secure.pdf) | [Word](individual/BSCS_PR03_fading-scaffolds-removing-support-as-students-become-secure.docx) |
| PR04 | Fluency practice: securing the essential steps | [PDF](individual/BSCS_PR04_fluency-practice-securing-the-essential-steps.pdf) | [Word](individual/BSCS_PR04_fluency-practice-securing-the-essential-steps.docx) |
| PR05 | Variation: changing examples to deepen understanding | [PDF](individual/BSCS_PR05_variation-changing-examples-to-deepen-understanding.pdf) | [Word](individual/BSCS_PR05_variation-changing-examples-to-deepen-understanding.docx) |
| PR06 | Interleaving: practising how to choose an approach | [PDF](individual/BSCS_PR06_interleaving-practising-how-to-choose-an-approach.pdf) | [Word](individual/BSCS_PR06_interleaving-practising-how-to-choose-an-approach.docx) |
| PR07 | Independent practice: helping students begin and sustain effort | [PDF](individual/BSCS_PR07_independent-practice-helping-students-begin-and-sustain-effort.pdf) | [Word](individual/BSCS_PR07_independent-practice-helping-students-begin-and-sustain-effort.docx) |
| PR08 | ‘What if?’ questions: vary a condition to deepen understanding | [PDF](individual/BSCS_PR08_what-if-questions-vary-a-condition-to-deepen-understanding.pdf) | [Word](individual/BSCS_PR08_what-if-questions-vary-a-condition-to-deepen-understanding.docx) |
| PR09 | Golden Silence and active observation: launching independent practice | [PDF](individual/BSCS_PR09_golden-silence-and-active-observation-launching-independent-practice.pdf) | [Word](individual/BSCS_PR09_golden-silence-and-active-observation-launching-independent-practice.docx) |
| PR10 | Consolidation: securing new learning before independent practice | [PDF](individual/BSCS_PR10_consolidation-securing-new-learning-before-independent-practice.pdf) | [Word](individual/BSCS_PR10_consolidation-securing-new-learning-before-independent-practice.docx) |
| PR11 | Problem-solving: applying secure knowledge in less familiar tasks | [PDF](individual/BSCS_PR11_problem-solving-applying-secure-knowledge-in-less-familiar-tasks.pdf) | [Word](individual/BSCS_PR11_problem-solving-applying-secure-knowledge-in-less-familiar-tasks.docx) |

## Drive Thinking for All

| Code | Guide | PDF | Word |
| --- | --- | --- | --- |
| DT01 | Wait time: giving everyone time to think | [PDF](individual/BSCS_DT01_wait-time-giving-everyone-time-to-think.pdf) | [Word](individual/BSCS_DT01_wait-time-giving-everyone-time-to-think.docx) |
| DT02 | Cold calling: involving everyone in questioning | [PDF](individual/BSCS_DT02_cold-calling-involving-everyone-in-questioning.pdf) | [Word](individual/BSCS_DT02_cold-calling-involving-everyone-in-questioning.docx) |
| DT03 | Think Pair Share: preparing everyone to answer | [PDF](individual/BSCS_DT03_think-pair-share-preparing-everyone-to-answer.pdf) | [Word](individual/BSCS_DT03_think-pair-share-preparing-everyone-to-answer.docx) |
| DT04 | Turn and Talk: structuring purposeful partner discussion | [PDF](individual/BSCS_DT04_turn-and-talk-structuring-purposeful-partner-discussion.pdf) | [Word](individual/BSCS_DT04_turn-and-talk-structuring-purposeful-partner-discussion.docx) |
| DT05 | Choral response: rehearsing brief answers together | [PDF](individual/BSCS_DT05_choral-response-rehearsing-brief-answers-together.pdf) | [Word](individual/BSCS_DT05_choral-response-rehearsing-brief-answers-together.docx) |
| DT06 | Probing questions: moving beyond the first answer | [PDF](individual/BSCS_DT06_probing-questions-moving-beyond-the-first-answer.pdf) | [Word](individual/BSCS_DT06_probing-questions-moving-beyond-the-first-answer.docx) |
| DT07 | Compare justify evaluate: questions that deepen reasoning | [PDF](individual/BSCS_DT07_compare-justify-evaluate-questions-that-deepen-reasoning.pdf) | [Word](individual/BSCS_DT07_compare-justify-evaluate-questions-that-deepen-reasoning.docx) |
| DT08 | Everyone–Together–Anyone: planning participation for the whole class | [PDF](individual/BSCS_DT08_everyone-together-anyone-planning-participation-for-the-whole-class.pdf) | [Word](individual/BSCS_DT08_everyone-together-anyone-planning-participation-for-the-whole-class.docx) |
| DT09 | Second Chance / No Opt Out: returning after ‘I don’t know’ | [PDF](individual/BSCS_DT09_second-chance-no-opt-out-returning-after-i-don-t-know.pdf) | [Word](individual/BSCS_DT09_second-chance-no-opt-out-returning-after-i-don-t-know.docx) |
| DT10 | Oracy for learning: teaching speaking and listening explicitly | [PDF](individual/BSCS_DT10_oracy-for-learning-teaching-speaking-and-listening-explicitly.pdf) | [Word](individual/BSCS_DT10_oracy-for-learning-teaching-speaking-and-listening-explicitly.docx) |
| DT11 | Everybody Writes / Silent Solo: thinking in writing before discussion | [PDF](individual/BSCS_DT11_everybody-writes-silent-solo-thinking-in-writing-before-discussion.pdf) | [Word](individual/BSCS_DT11_everybody-writes-silent-solo-thinking-in-writing-before-discussion.docx) |
| DT12 | Precise answers / Don’t round up: helping students refine a response | [PDF](individual/BSCS_DT12_precise-answers-don-t-round-up-helping-students-refine-a-response.pdf) | [Word](individual/BSCS_DT12_precise-answers-don-t-round-up-helping-students-refine-a-response.docx) |

## Check & Adapt

| Code | Guide | PDF | Word |
| --- | --- | --- | --- |
| CA01 | Mini-whiteboards: checking everyone's understanding | [PDF](individual/BSCS_CA01_mini-whiteboards-checking-everyone-s-understanding.pdf) | [Word](individual/BSCS_CA01_mini-whiteboards-checking-everyone-s-understanding.docx) |
| CA02 | Hinge questions: deciding whether to move on | [PDF](individual/BSCS_CA02_hinge-questions-deciding-whether-to-move-on.pdf) | [Word](individual/BSCS_CA02_hinge-questions-deciding-whether-to-move-on.docx) |
| CA03 | Checking for understanding during explanations | [PDF](individual/BSCS_CA03_checking-for-understanding-during-explanations.pdf) | [Word](individual/BSCS_CA03_checking-for-understanding-during-explanations.docx) |
| CA04 | Circulation: sampling independent work and responding | [PDF](individual/BSCS_CA04_circulation-sampling-independent-work-and-responding.pdf) | [Word](individual/BSCS_CA04_circulation-sampling-independent-work-and-responding.docx) |
| CA05 | Exit tickets: identifying what needs revisiting | [PDF](individual/BSCS_CA05_exit-tickets-identifying-what-needs-revisiting.pdf) | [Word](individual/BSCS_CA05_exit-tickets-identifying-what-needs-revisiting.docx) |
| CA06 | Pause and Fix: responding to a common misconception | [PDF](individual/BSCS_CA06_pause-and-fix-responding-to-a-common-misconception.pdf) | [Word](individual/BSCS_CA06_pause-and-fix-responding-to-a-common-misconception.docx) |
| CA07 | Adapt and Support Extend and Challenge: responding to different needs | [PDF](individual/BSCS_CA07_adapt-and-support-extend-and-challenge-responding-to-different-needs.pdf) | [Word](individual/BSCS_CA07_adapt-and-support-extend-and-challenge-responding-to-different-needs.docx) |
| CA08 | Micro-decisions: notice, interpret and respond in the moment | [PDF](individual/BSCS_CA08_micro-decisions-notice-interpret-and-respond-in-the-moment.pdf) | [Word](individual/BSCS_CA08_micro-decisions-notice-interpret-and-respond-in-the-moment.docx) |
| CA09 | High success rates: deciding when students are ready for independence | [PDF](individual/BSCS_CA09_high-success-rates-deciding-when-students-are-ready-for-independence.pdf) | [Word](individual/BSCS_CA09_high-success-rates-deciding-when-students-are-ready-for-independence.docx) |
| CA10 | Walking-talking mocks: attempt, diagnose, model and re-check | [PDF](individual/BSCS_CA10_walking-talking-mocks-attempt-diagnose-model-and-re-check.pdf) | [Word](individual/BSCS_CA10_walking-talking-mocks-attempt-diagnose-model-and-re-check.docx) |
| CA11 | Confidence scores: finding confidently held errors | [PDF](individual/BSCS_CA11_confidence-scores-finding-confidently-held-errors.pdf) | [Word](individual/BSCS_CA11_confidence-scores-finding-confidently-held-errors.docx) |
| CA12 | Learner-generated examples: testing concept boundaries | [PDF](individual/BSCS_CA12_learner-generated-examples-testing-concept-boundaries.pdf) | [Word](individual/BSCS_CA12_learner-generated-examples-testing-concept-boundaries.docx) |

## Feedback to Improve

| Code | Guide | PDF | Word |
| --- | --- | --- | --- |
| FI01 | Actionable feedback: giving students a useful next step | [PDF](individual/BSCS_FI01_actionable-feedback-giving-students-a-useful-next-step.pdf) | [Word](individual/BSCS_FI01_actionable-feedback-giving-students-a-useful-next-step.docx) |
| FI02 | Whole-class feedback: responding to patterns in work | [PDF](individual/BSCS_FI02_whole-class-feedback-responding-to-patterns-in-work.pdf) | [Word](individual/BSCS_FI02_whole-class-feedback-responding-to-patterns-in-work.docx) |
| FI03 | Self-checking: teaching students to improve their own work | [PDF](individual/BSCS_FI03_self-checking-teaching-students-to-improve-their-own-work.pdf) | [Word](individual/BSCS_FI03_self-checking-teaching-students-to-improve-their-own-work.docx) |
| FI04 | Peer critique: using criteria to improve work | [PDF](individual/BSCS_FI04_peer-critique-using-criteria-to-improve-work.pdf) | [Word](individual/BSCS_FI04_peer-critique-using-criteria-to-improve-work.docx) |
| FI05 | Feedback tasks: planning time to act on feedback | [PDF](individual/BSCS_FI05_feedback-tasks-planning-time-to-act-on-feedback.pdf) | [Word](individual/BSCS_FI05_feedback-tasks-planning-time-to-act-on-feedback.docx) |
| FI06 | Feedback follow-up: checking improvement on a new task | [PDF](individual/BSCS_FI06_feedback-follow-up-checking-improvement-on-a-new-task.pdf) | [Word](individual/BSCS_FI06_feedback-follow-up-checking-improvement-on-a-new-task.docx) |
| FI07 | The visualiser: discussing and improving student work | [PDF](individual/BSCS_FI07_the-visualiser-discussing-and-improving-student-work.pdf) | [Word](individual/BSCS_FI07_the-visualiser-discussing-and-improving-student-work.docx) |
| FI08 | Review Cards: turning errors into future retrieval | [PDF](individual/BSCS_FI08_review-cards-turning-errors-into-future-retrieval.pdf) | [Word](individual/BSCS_FI08_review-cards-turning-errors-into-future-retrieval.docx) |

## Do Now / Retrieval across time

| Code | Guide | PDF | Word |
| --- | --- | --- | --- |
| DN06 | Retrieval homework: revisiting learning beyond the lesson | [PDF](individual/BSCS_DN06_retrieval-homework-revisiting-learning-beyond-the-lesson.pdf) | [Word](individual/BSCS_DN06_retrieval-homework-revisiting-learning-beyond-the-lesson.docx) |
| DN07 | Getting students on board with retrieval: explain, demonstrate and build habits | [PDF](individual/BSCS_DN07_getting-students-on-board-with-retrieval-explain-demonstrate-and-build-habits.pdf) | [Word](individual/BSCS_DN07_getting-students-on-board-with-retrieval-explain-demonstrate-and-build-habits.docx) |
